// Paquete donde se encuentra el fragmento
package com.example.taller2.fragments

// Importación de clases necesarias
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.taller2.R
import com.example.taller2.activities.LoginActivity


class MensajeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // retorna la vista definida en mensaje.xml
        val view = inflater.inflate(R.layout.mensaje, container, false)

        return view
    }
}

