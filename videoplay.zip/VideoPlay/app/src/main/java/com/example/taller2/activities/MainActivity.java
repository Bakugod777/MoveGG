package com.example.taller2.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.taller2.fragments.CarritoFragment;
import com.example.taller2.fragments.CategoriaFragment;
import com.example.taller2.fragments.EditarFragment;
import com.example.taller2.fragments.MensajeFragment;
import com.example.taller2.fragments.PerfilFragment;
import com.example.taller2.fragments.ProductoFragment;
import com.example.taller2.R;

public class MainActivity extends AppCompatActivity {

    private Button btnVerCategorias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ImageButton btnPerfil = findViewById(R.id.button);
        ImageButton btnLogo = findViewById(R.id.button_logo);
        ImageButton btnVerProductos = findViewById(R.id.btn_ver_productos);
        ImageButton btnVerCarrito = findViewById(R.id.btn_ver_carrito);
        btnVerCategorias = findViewById(R.id.btn_ver_categorias);

        // Inicialmente ocultamos el botón de categorías
        btnVerCategorias.setVisibility(View.GONE);

        // Abrir ProductoFragment y mostrar botón de categorías
        btnVerProductos.setOnClickListener(v -> {
            abrirFragmento(new ProductoFragment());
            btnVerCategorias.setVisibility(View.VISIBLE);
        });

        // Abrir CategoríaFragment (solo cuando está en ProductoFragment)
        btnVerCategorias.setOnClickListener(v -> abrirFragmento(new CategoriaFragment()));

        // Abrir PerfilFragment y ocultar botón de categorías
        btnPerfil.setOnClickListener(v -> {
            abrirFragmento(new PerfilFragment());
            btnVerCategorias.setVisibility(View.GONE);
        });

        // Abrir CarritoFragment
        btnVerCarrito.setOnClickListener(v -> {
            abrirFragmento(new CarritoFragment());
            btnVerCategorias.setVisibility(View.GONE);
        });

        btnLogo.setOnClickListener(v -> {
            abrirFragmento(new MensajeFragment());
            btnVerCategorias.setVisibility(View.GONE);
        });
    }

    // Método para abrir EditarFragment desde PerfilFragment
    public void abrirEditarFragment() {
        abrirFragmento(new EditarFragment());
    }

    // Hacer este método público para que sea accesible desde otros Fragments
    public void abrirFragmento(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }
}

